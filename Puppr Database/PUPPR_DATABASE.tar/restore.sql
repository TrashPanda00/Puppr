--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.1
-- Dumped by pg_dump version 12.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "SEPDB_3";
--
-- Name: SEPDB_3; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "SEPDB_3" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_Denmark.1252' LC_CTYPE = 'English_Denmark.1252';


ALTER DATABASE "SEPDB_3" OWNER TO postgres;

\connect "SEPDB_3"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: commentlikes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.commentlikes (
    comment_id bigint NOT NULL,
    handle character varying(50)
);


ALTER TABLE public.commentlikes OWNER TO postgres;

--
-- Name: commentlikes_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.commentlikes_comment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.commentlikes_comment_id_seq OWNER TO postgres;

--
-- Name: commentlikes_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.commentlikes_comment_id_seq OWNED BY public.commentlikes.comment_id;


--
-- Name: comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comments (
    comment_id bigint NOT NULL,
    body character varying(500),
    handle character varying(50),
    likes integer,
    time_posted timestamp without time zone,
    post_id bigint NOT NULL
);


ALTER TABLE public.comments OWNER TO postgres;

--
-- Name: comments_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.comments_comment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.comments_comment_id_seq OWNER TO postgres;

--
-- Name: comments_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.comments_comment_id_seq OWNED BY public.comments.comment_id;


--
-- Name: comments_post_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.comments_post_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.comments_post_id_seq OWNER TO postgres;

--
-- Name: comments_post_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.comments_post_id_seq OWNED BY public.comments.post_id;


--
-- Name: doglikes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.doglikes (
    dog_id bigint NOT NULL,
    handle character varying(50) NOT NULL
);


ALTER TABLE public.doglikes OWNER TO postgres;

--
-- Name: doglikes_dog_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.doglikes_dog_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.doglikes_dog_id_seq OWNER TO postgres;

--
-- Name: doglikes_dog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.doglikes_dog_id_seq OWNED BY public.doglikes.dog_id;


--
-- Name: dogs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dogs (
    dog_id bigint NOT NULL,
    dog_name character varying(50),
    image_url bytea,
    info character varying(100),
    dog_owner character varying(50),
    likes numeric(10,0)
);


ALTER TABLE public.dogs OWNER TO postgres;

--
-- Name: dogs_dog_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dogs_dog_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dogs_dog_id_seq OWNER TO postgres;

--
-- Name: dogs_dog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dogs_dog_id_seq OWNED BY public.dogs.dog_id;


--
-- Name: likes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.likes (
    post_id bigint NOT NULL,
    handle character varying(50) NOT NULL
);


ALTER TABLE public.likes OWNER TO postgres;

--
-- Name: likes_post_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.likes_post_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.likes_post_id_seq OWNER TO postgres;

--
-- Name: likes_post_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.likes_post_id_seq OWNED BY public.likes.post_id;


--
-- Name: posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.posts (
    post_id bigint NOT NULL,
    image_url bytea,
    name character varying(50),
    handle character varying(50),
    likes numeric(10,0),
    time_posted timestamp without time zone,
    text character varying(500)
);


ALTER TABLE public.posts OWNER TO postgres;

--
-- Name: posts_post_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.posts_post_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.posts_post_id_seq OWNER TO postgres;

--
-- Name: posts_post_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.posts_post_id_seq OWNED BY public.posts.post_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    handle character varying(50) NOT NULL,
    name character varying(50) NOT NULL,
    lastname character varying(50) NOT NULL,
    imageurl bytea,
    password character varying(70) NOT NULL,
    email character varying(50) NOT NULL,
    birthday date,
    gender character varying(1),
    bio character varying(500),
    usertype character varying(5),
    status character varying(10)
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: commentlikes comment_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commentlikes ALTER COLUMN comment_id SET DEFAULT nextval('public.commentlikes_comment_id_seq'::regclass);


--
-- Name: comments comment_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments ALTER COLUMN comment_id SET DEFAULT nextval('public.comments_comment_id_seq'::regclass);


--
-- Name: comments post_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments ALTER COLUMN post_id SET DEFAULT nextval('public.comments_post_id_seq'::regclass);


--
-- Name: doglikes dog_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doglikes ALTER COLUMN dog_id SET DEFAULT nextval('public.doglikes_dog_id_seq'::regclass);


--
-- Name: dogs dog_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dogs ALTER COLUMN dog_id SET DEFAULT nextval('public.dogs_dog_id_seq'::regclass);


--
-- Name: likes post_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.likes ALTER COLUMN post_id SET DEFAULT nextval('public.likes_post_id_seq'::regclass);


--
-- Name: posts post_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts ALTER COLUMN post_id SET DEFAULT nextval('public.posts_post_id_seq'::regclass);


--
-- Data for Name: commentlikes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.commentlikes (comment_id, handle) FROM stdin;
\.
COPY public.commentlikes (comment_id, handle) FROM '$$PATH$$/2881.dat';

--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.comments (comment_id, body, handle, likes, time_posted, post_id) FROM stdin;
\.
COPY public.comments (comment_id, body, handle, likes, time_posted, post_id) FROM '$$PATH$$/2883.dat';

--
-- Data for Name: doglikes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.doglikes (dog_id, handle) FROM stdin;
\.
COPY public.doglikes (dog_id, handle) FROM '$$PATH$$/2886.dat';

--
-- Data for Name: dogs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dogs (dog_id, dog_name, image_url, info, dog_owner, likes) FROM stdin;
\.
COPY public.dogs (dog_id, dog_name, image_url, info, dog_owner, likes) FROM '$$PATH$$/2888.dat';

--
-- Data for Name: likes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.likes (post_id, handle) FROM stdin;
\.
COPY public.likes (post_id, handle) FROM '$$PATH$$/2890.dat';

--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.posts (post_id, image_url, name, handle, likes, time_posted, text) FROM stdin;
\.
COPY public.posts (post_id, image_url, name, handle, likes, time_posted, text) FROM '$$PATH$$/2892.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (handle, name, lastname, imageurl, password, email, birthday, gender, bio, usertype, status) FROM stdin;
\.
COPY public.users (handle, name, lastname, imageurl, password, email, birthday, gender, bio, usertype, status) FROM '$$PATH$$/2894.dat';

--
-- Name: commentlikes_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.commentlikes_comment_id_seq', 1, false);


--
-- Name: comments_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.comments_comment_id_seq', 117, true);


--
-- Name: comments_post_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.comments_post_id_seq', 1, false);


--
-- Name: doglikes_dog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.doglikes_dog_id_seq', 1, false);


--
-- Name: dogs_dog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dogs_dog_id_seq', 19, true);


--
-- Name: likes_post_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.likes_post_id_seq', 1, false);


--
-- Name: posts_post_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.posts_post_id_seq', 48, true);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (comment_id);


--
-- Name: doglikes doglikes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doglikes
    ADD CONSTRAINT doglikes_pkey PRIMARY KEY (handle, dog_id);


--
-- Name: dogs dogs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dogs
    ADD CONSTRAINT dogs_pkey PRIMARY KEY (dog_id);


--
-- Name: likes likes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT likes_pkey PRIMARY KEY (handle, post_id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (post_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (handle);


--
-- Name: commentlikes commentlikes_handle_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commentlikes
    ADD CONSTRAINT commentlikes_handle_fkey FOREIGN KEY (handle) REFERENCES public.users(handle);


--
-- Name: comments comments_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.posts(post_id) ON DELETE CASCADE;


--
-- Name: doglikes doglikes_dog_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doglikes
    ADD CONSTRAINT doglikes_dog_id_fkey FOREIGN KEY (dog_id) REFERENCES public.dogs(dog_id) ON DELETE CASCADE;


--
-- Name: doglikes doglikes_handle_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doglikes
    ADD CONSTRAINT doglikes_handle_fkey FOREIGN KEY (handle) REFERENCES public.users(handle);


--
-- Name: dogs dogs_dog_owner_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dogs
    ADD CONSTRAINT dogs_dog_owner_fkey FOREIGN KEY (dog_owner) REFERENCES public.users(handle);


--
-- Name: likes likes_handle_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT likes_handle_fkey FOREIGN KEY (handle) REFERENCES public.users(handle);


--
-- Name: posts posts_handle_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_handle_fkey FOREIGN KEY (handle) REFERENCES public.users(handle);


--
-- PostgreSQL database dump complete
--

